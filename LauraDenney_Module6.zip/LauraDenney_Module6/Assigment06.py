#-------------------------------------------------#
# Title: Functions and Classes
# Dev:   RRoot
# Date:  July 16, 2012
# ChangeLog: (Who, When, What)
#   RRoot, 11/02/2016, Created starting template
#   Laura Denney, 2/11/2018, Added code to complete assignment 5
#   Laura Denney 2/19/2018, Added code to complete assignment 6
#https://www.tutorialspoint.com/python/python_dictionary.htm
#-------------------------------------------------#

#---Data------------------------------------------------------

STRFILENAME = "C:\_PythonClass\Todo.txt" #file we're working with
holdDic = {} #holds return dictionary from AddItems
lstDic = [] #a list containing the dictionary variables
strData = "" #holds return string from RemoveItems
strChoice = "" #hold user choice
inList = False #holds boolean from RemoveItems that checks if item in list

#---Processing-----------------------------------------------


class FileProcessor(object):

    # Step 1 - Load data from a file
    # When the program starts, load each "row" of data
    # in "ToDo.txt" into a python Dictionary.
    # Add the each dictionary "row" to a python list "table"
    @staticmethod
    def ReadFile(file, currentlist):
        holdFile = open(file, "r") #open file in read mode
        for row in holdFile:
            task, priority = row.strip().split(',') #makes lower case, strips excess and splits by comma
            dicRow = {task.lower(): priority.lower()} #dictionary variable to contain paired tasks and priorities
            currentlist.append(dicRow) #adds dictionaries to list
        holdFile.close()
        return currentlist

# Step 2 - Display a menu of choices to the user
    @staticmethod
    def ShowMenu():
        strMenu = ("""
            Menu of Options
            1) Show current data
            2) Add a new item
            3) Remove an existing item
            4) Save Data to File
            5) Exit Program
            """)
        return strMenu
    # get user's choice of menu option
    @staticmethod
    def GetChoice():
        strChoose = str(input("Which option would you like to perform? (1 to 5): "))
        return strChoose.strip()

 # Step 3 -Show the current items in the table
    @staticmethod
    def ShowItems(currentlist):
        strItems = "Current items in list: \n"
        for x in currentlist:
            strItems += str(x) + "\n"
        return strItems

# Step 4 - Add a new item to the list/Table
    @staticmethod
    def AddItems():
        strTask = input("What task would you like to add?: ")
        strPriority = input("What is the priority of that task? (high/low): ")
        dicRow = {strTask.lower(): strPriority.lower()}
        global lstDic
        lstDic.append(dicRow)
        return dicRow

# Step 5 - Remove an item from the list/Table
    @staticmethod
    def RemoveItem(currentlist):
        strTask = input("What task would you like to remove?: ")
        bulFlag = False
        for dictionaries in currentlist:
            if strTask.lower() in dictionaries:
                bulFlag = True
                global lstDic
                lstDic.remove(dictionaries)
            return bulFlag, strTask.lower()

# Step 6 - Save tasks to the ToDo.txt file
    @staticmethod
    def SaveFile(file, currentlist):
        curFile = open(file, "w")
        for dictionaries in currentlist:
            for myKey, myValue in dictionaries.items():
                curFile.write(myKey.title() + "," + myValue)
            curFile.write("\n")
        curFile.close()

#---Presentation------------------------------------------------------------------
lstDic = FileProcessor.ReadFile(STRFILENAME, lstDic)

print("Welcome to your to-do list program, please pick a choice from below:")

while(True):
    # Step 2 - Show menu and then get user menu choice
    print(FileProcessor.ShowMenu())
    strChoice = FileProcessor.GetChoice()
    print() #creates space for formatting

    # Step 3 -Show the current items in the table
    if (strChoice == '1'):
        print(FileProcessor.ShowItems(lstDic))

    # Step 4 - Add a new item to the list/Table
    elif(strChoice == '2'):
        holdDic = FileProcessor.AddItems()
        print(holdDic, "successfully added to the list.")

    # Step 5 - Remove an item from the list/Table
    elif(strChoice == '3'):
        inList, strData = FileProcessor.RemoveItem(lstDic)
        if inList:
            print(strData.title(), "successfully removed from list.")
        else:
            print(strData.title(), "not currently in list, consider adding", strData.title(), "instead.")

    # Step 6 - Save tasks to the ToDo.txt file
    elif(strChoice == '4'):
        FileProcessor.SaveFile(STRFILENAME, lstDic)
        print("Data successfully saved.")

    #Step 7 - exit the program
    elif (strChoice == '5'):
        print("Thank you for using your friendly to-do list program. \nGoodbye.")
        break #and Exit the program
    else:
        print("Please choose a valid option.")


