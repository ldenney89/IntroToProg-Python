#-------------------------------------------------#
# Title: Working with Dictionaries
# Dev:   RRoot
# Date:  July 16, 2012
# ChangeLog: (Who, When, What)
#   RRoot, 11/02/2016, Created starting template
#   Laura Denney, 2/11/2018, Added code to complete assignment 5
#https://www.tutorialspoint.com/python/python_dictionary.htm
#-------------------------------------------------#

objFileName = open("C:\_PythonClass\Todo.txt", "r") #open file in read mode
strData = "" #string to store each line of data file
dicRow = {} #dictionary variable to contain paired tasks and priorities
lstTable = [] #a list containing the dictionary variables

# Step 1 - Load data from a file
    # When the program starts, load each "row" of data 
    # in "ToDo.txt" into a python Dictionary.
    # Add the each dictionary "row" to a python list "table"
for row in objFileName:
    strData = row.lower()
    if "\n" in row:
        strData = strData[:-1] #removes \n if contained in string
    dicRow = {strData.split(",")[0]: strData.split(",")[1]} #split data by the comma
    lstTable += [dicRow, ] #add whats in dictionary to list

# Step 2 - Display a menu of choices to the user
print("Welcome to your to-do list program, please pick a choice from below:")

while(True):
    print ("""
    Menu of Options
    1) Show current data
    2) Add a new item
    3) Remove an existing item
    4) Save Data to File
    5) Exit Program
    """)
    strChoice = str(input("Which option would you like to perform? (1 to 5): "))
    print()#adding a new line

    # Step 3 -Show the current items in the table
    if (strChoice.strip() == '1'):
        print("Current items in list: ")
        for x in lstTable:
            print(x)
        continue
    # Step 4 - Add a new item to the list/Table
    elif(strChoice.strip() == '2'):
        strTask = input("What task would you like to add?: ")
        strPriority = input("What is the priority of that task? (high/low): ")
        dicRow = {strTask.lower(): strPriority.lower()}
        lstTable += [dicRow, ]
        print(dicRow, "successfully added to the list.")
        continue

    # Step 5 - Remove an item from the list/Table
    elif(strChoice.strip() == '3'):
        strTask = input("What task would you like to remove?: ")
        bulFlag = False
        for dictionaries in lstTable:
            if strTask.lower() in dictionaries:
                lstTable.remove(dictionaries)
                bulFlag = True
                print(strTask.title(), "successfully removed from list.")
        if not bulFlag:
            print(strTask.title(), "not currently in list, consider adding", strTask.title(), "instead.")
        continue
    # Step 6 - Save tasks to the ToDo.txt file
    elif(strChoice.strip() == '4'):
        objFileName = open("C:\_PythonClass\Todo.txt", "w")
        for dictionaries in lstTable:
            for myKey, myValue in dictionaries.items():
                objFileName.write(myKey.title() + "," + myValue)
            objFileName.write("\n")
        objFileName.close()
        print("Data successfully saved.")
        continue
    #Step 7 - exit the program
    elif (strChoice.strip() == '5'):
        print("Thank you for using your friendly to-do list program. \nGoodbye.")
        break #and Exit the program
    else:
        print("Please choose a valid option.")
        continue

